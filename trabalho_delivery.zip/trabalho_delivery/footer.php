<footer class="container-fluid bg-4 text-center" style="background-color: rgba(255, 255, 128, .5); margin-top: 10px; padding-top: 10px; min-height: 50px;">
	

	<div class="horario small-5 medium-3 small-offset-1 medium-offset-0 columns">
                        <h4 class="footer-section-title">Horário de Atendimento:</h4>
						
                        Seg-Sab: 11h30 - 24h00<br>
                        Domingo 18h00 - 24h00</p>
                    </div>
<div class = "copyright small-12 columns"><p>
	2020 &copy; Sistemas para Internet</p>
                    
 </div>

	

