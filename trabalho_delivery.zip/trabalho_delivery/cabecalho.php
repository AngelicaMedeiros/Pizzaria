<div class="jumbotron text-center" style="background-color:#CF2929">
	
    <h1>Pizzaria Delivery</h1>
    <p>Pizzaria Forno a Lenha</p>
	
</div>